<?php
/*
Plugin Name: Kara Simple FileManager
Description: Minimalist WP file manager (no JSON, no elFinder, stealth-style).
Version: 1.0
Author: Kara
*/

add_action('admin_menu', function () {
  add_menu_page('Kara FileManager', 'FileManager', 'manage_options', 'kara_fm', 'kara_fm_ui');
});

function kara_fm_ui() {
  $base = ABSPATH;
  $dir = isset($_GET['dir']) ? realpath($base . '/' . $_GET['dir']) : $base;

  if (!$dir || strpos($dir, $base) !== 0) {
    die("Access denied.");
  }

  if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['newfile']) && $_POST['newfile']) {
      file_put_contents($dir . '/' . basename($_POST['newfile']), '');
    }
    if (isset($_POST['newdir']) && $_POST['newdir']) {
      mkdir($dir . '/' . basename($_POST['newdir']));
    }
    if (isset($_FILES['upload']) && $_FILES['upload']['error'] === 0) {
      move_uploaded_file($_FILES['upload']['tmp_name'], $dir . '/' . basename($_FILES['upload']['name']));
    }
    if (isset($_POST['rename_old']) && isset($_POST['rename_new'])) {
      rename($dir . '/' . basename($_POST['rename_old']), $dir . '/' . basename($_POST['rename_new']));
    }
    if (isset($_POST['delete'])) {
      $target = $dir . '/' . basename($_POST['delete']);
      if (is_dir($target)) {
        rmdir($target);
      } else {
        unlink($target);
      }
    }
    if (isset($_POST['move_name']) && isset($_POST['move_to'])) {
      rename($dir . '/' . basename($_POST['move_name']), $base . '/' . trim($_POST['move_to'], '/'));
    }
  }

  echo "<h2>File Manager</h2>";
  echo "<p>Current Dir: <b>" . str_replace($base, '', $dir) . "</b></p>";
  echo "<ul>";
  foreach (scandir($dir) as $f) {
    if ($f === '.') continue;
    $path = $dir . '/' . $f;
    $link = admin_url('admin.php?page=kara_fm&dir=' . urlencode(str_replace($base, '', $path)));
    echo "<li>" . (is_dir($path) ? "[DIR] <a href='$link'>$f</a>" : $f) . "</li>";
  }
  echo "</ul>";

  echo <<<FORM
<form method="post" enctype="multipart/form-data">
  <h3>Create / Upload</h3>
  File: <input type="text" name="newfile">
  Dir: <input type="text" name="newdir">
  Upload: <input type="file" name="upload">
  <button type="submit">Submit</button>
</form>
<form method="post">
  <h3>Rename</h3>
  Old: <input type="text" name="rename_old">
  New: <input type="text" name="rename_new">
  <button type="submit">Rename</button>
</form>
<form method="post">
  <h3>Delete</h3>
  File/Dir: <input type="text" name="delete">
  <button type="submit">Delete</button>
</form>
<form method="post">
  <h3>Move</h3>
  Name: <input type="text" name="move_name">
  To Path: <input type="text" name="move_to">
  <button type="submit">Move</button>
</form>
FORM;
}
?>
